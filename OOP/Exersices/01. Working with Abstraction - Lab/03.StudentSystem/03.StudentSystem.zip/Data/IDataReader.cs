﻿namespace StudentSystem.Data
{
    public interface IDataReader
    {
        string Read();
    }
}
