﻿namespace StudentSystem.Data
{
    public interface IDataWrite
    {
        void Write(object obj);
    }
}
