﻿namespace WildFarm.Food
{
    public enum TypeFood
    {
        Vegetable = 1,
        Fruit = 2,
        Meat = 3,
        Seeds = 4
    }
}