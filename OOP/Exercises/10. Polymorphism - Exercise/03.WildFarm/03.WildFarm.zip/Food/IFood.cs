﻿namespace WildFarm.Food
{
    public interface IFood
    {
        int Quantity { get; }
    }
}