﻿namespace FoodShortage
{
    public interface ICitizen
    {
        string Id { get; set; }

        string Birthdate { get; set; }
    }
}