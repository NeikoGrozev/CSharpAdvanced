﻿namespace FoodShortage
{
    public interface IRebel
    {
        string Group { get; set; }
    }
}