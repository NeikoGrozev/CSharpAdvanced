﻿namespace BirthdayCelebrations
{
    public abstract class Society
    {
        public abstract bool FindingYear(string year);       
    }
}