﻿namespace BirthdayCelebrations
{
    public interface IPet
    {
        string Name { get; set; }
    }
}