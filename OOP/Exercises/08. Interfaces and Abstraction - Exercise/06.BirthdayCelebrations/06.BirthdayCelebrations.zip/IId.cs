﻿namespace BirthdayCelebrations
{
    public interface IId
    {
         string Id { get; set; }
    }
}