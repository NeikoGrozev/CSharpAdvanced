﻿namespace BirthdayCelebrations
{
    public interface IRobot
    {
        string Model { get; set; }
    }
}