﻿namespace BorderControl
{
    public abstract class Society
    {
        public abstract bool FindingFakeId(string number);       
    }
}
