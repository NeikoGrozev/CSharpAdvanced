﻿namespace Ferrari
{
    public interface ICar
    {
        string Model { get; set; }

        string Breaks { get; set; }

        string GasPedal { get; set; }

        string Driver { get; set; }
    }
}