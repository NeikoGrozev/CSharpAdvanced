﻿namespace Telephony
{
    public interface ICalling
    {
        string Calling(string phoneNumber);
    }
}