﻿namespace Telephony
{
    public interface IBrowsing
    {
        string Browsing(string webSite);
    }
}