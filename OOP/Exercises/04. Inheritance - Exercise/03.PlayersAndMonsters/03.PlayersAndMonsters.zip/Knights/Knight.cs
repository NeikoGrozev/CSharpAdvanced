﻿namespace PlayersAndMonsters.Knights
{
    public class Knight : Hero
    {
        public Knight(string username, int level)
            :base(username, level)
        {
        }
    }
}
