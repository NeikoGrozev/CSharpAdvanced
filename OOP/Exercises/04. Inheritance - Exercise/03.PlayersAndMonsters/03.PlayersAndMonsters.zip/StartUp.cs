﻿namespace PlayersAndMonsters
{
    using PlayersAndMonsters.Wizards;
    using System;

    public class StartUp
    {
        public static void Main()
        {
            //string name = "Pesho";
            //int level = 3;

            //SoulMaster mon = new SoulMaster(name, level);
            

            //Console.WriteLine(mon);
        }
    }
}
