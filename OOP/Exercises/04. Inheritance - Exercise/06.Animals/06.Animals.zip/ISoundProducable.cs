﻿namespace Animals
{
    public interface ISoundProducable
    {
        string ProduceSound();
    }
}
