﻿namespace NeedForSpeed.Cars
{
    public class Car: Vehicle
    {
        public Car(int horsePower, double fuel)
            :base(horsePower, fuel)
        {
            this.DefaultFuelConsumption = 3;
        }
    }
}
