﻿namespace NeedForSpeed.Motorcycles
{
    public class CrossMotorcycle: Motorcycle
    {
        public CrossMotorcycle(int horsePower, int fuel)
            :base(horsePower, fuel)
        {
        }
    }
}
