﻿namespace Zoo.Reptils
{
    public class Reptile : Animal
    {
        public Reptile(string name)
            : base(name)
        {
        }
    }
}
