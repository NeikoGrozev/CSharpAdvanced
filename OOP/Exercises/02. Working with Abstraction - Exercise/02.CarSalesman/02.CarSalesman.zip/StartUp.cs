﻿namespace CarSalesman
{
    class StartUp
    {
        static void Main()
        {
            Runner.Run();
        }
    }
}
