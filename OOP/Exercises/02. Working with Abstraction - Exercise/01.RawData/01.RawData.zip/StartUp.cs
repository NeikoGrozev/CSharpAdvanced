﻿namespace RawData
{
    public class StartUp
    {
        public static void Main()
        {
            Runner.Run();
        }
    }
}
