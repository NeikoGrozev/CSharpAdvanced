﻿namespace RawData.Data
{
    public interface IDataWriter
    {
        void Write(object obj);
    }
}
