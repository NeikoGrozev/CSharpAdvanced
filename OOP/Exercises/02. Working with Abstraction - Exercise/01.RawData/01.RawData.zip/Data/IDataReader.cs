﻿namespace RawData.Data
{
    public interface IDataReader
    {
        string Read();
    }
}
