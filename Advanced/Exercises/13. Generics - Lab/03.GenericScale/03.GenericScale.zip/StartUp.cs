﻿namespace GenericScale
{
    using System;

    public class StartUp
    {
        public static void Main()
        {
        //    EqualityScale<int> test = new EqualityScale<int>(5, 5);
        //    Console.WriteLine(test.AreEqual());
        }
    }
}
