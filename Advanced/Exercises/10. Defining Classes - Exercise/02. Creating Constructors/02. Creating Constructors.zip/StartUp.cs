﻿namespace DefiningClasses
{
    using System;

    public class StartUp
    {
        public static void Main()
        {
            //string name = Console.ReadLine();
            //int age = int.Parse(Console.ReadLine());

            Person personOne = new Person("Pesho", 11);

            //Person personTwo = new Person();
            //personTwo.Name = "No name";
            //personTwo.Age = int.Parse(Console.ReadLine());

            //Person personThird = new Person();
            //personTwo.Name = Console.ReadLine();
            //personTwo.Age = int.Parse(Console.ReadLine());
        }
    }
}
